package com.local.whalepet

import android.animation.ObjectAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min
import kotlin.random.Random

class PetService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var view: ImageView
    private lateinit var params: WindowManager.LayoutParams
    private var bobber: ObjectAnimator? = null

    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var dragging = false

    private val lines = arrayOf(
        "鲸鱼娘在这儿～",
        "今天也要好好干活哦",
        "要不要摸摸头？",
        "拖到边上我会躲起来",
    )

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val size = dp(130)
        view = ImageView(this).apply {
            setImageBitmap(assets.open("whale.png").use { BitmapFactory.decodeStream(it) })
            scaleType = ImageView.ScaleType.FIT_CENTER
        }

        params = WindowManager.LayoutParams(
            size,
            (size * 1.07f).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - size - dp(16)
            y = resources.displayMetrics.heightPixels - size * 2
        }

        view.setOnTouchListener { _, event -> onTouch(event) }
        wm.addView(view, params)
        startBob()
    }

    private fun onTouch(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                startX = params.x
                startY = params.y
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (event.rawX - downX).toInt()
                val dy = (event.rawY - downY).toInt()
                if (abs(dx) + abs(dy) > 8) dragging = true
                if (dragging) {
                    params.x = startX + dx
                    params.y = startY + dy
                    wm.updateViewLayout(view, params)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) snapToEdge() else react()
                return true
            }
        }
        return false
    }

    private fun snapToEdge() {
        val screenW = resources.displayMetrics.widthPixels
        val centre = params.x + params.width / 2
        val target = if (centre < screenW / 2) -params.width / 3 else screenW - params.width * 2 / 3
        val maxY = resources.displayMetrics.heightPixels - params.height
        params.y = params.y.coerceIn(0, maxY)
        animateX(target)
    }

    private fun animateX(target: Int) {
        val from = params.x
        val anim = ObjectAnimator.ofInt(0, 1).setDuration(220)
        anim.addUpdateListener {
            params.x = from + ((target - from) * (it.animatedValue as Int))
            wm.updateViewLayout(view, params)
        }
        anim.start()
    }

    private fun react() {
        val jump = ObjectAnimator.ofFloat(view, "translationY", 0f, -dp(18).toFloat(), 0f)
        jump.duration = 420
        jump.start()
        Toast.makeText(this, lines[Random.nextInt(lines.size)], Toast.LENGTH_SHORT).show()
    }

    private fun startBob() {
        bobber = ObjectAnimator.ofFloat(view, "translationY", 0f, -dp(6).toFloat()).apply {
            duration = 1800
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "whale-pet"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "鲸鱼娘桌宠", NotificationManager.IMPORTANCE_LOW),
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("鲸鱼娘桌宠运行中")
            .setContentText("点一下她，或拖到屏幕边缘")
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        bobber?.cancel()
        if (::view.isInitialized) runCatching { wm.removeView(view) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
