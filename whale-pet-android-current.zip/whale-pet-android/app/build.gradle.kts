plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.local.whalepet"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.local.whalepet"
        minSdk = 26
        targetSdk = 34
        versionCode = (project.findProperty("vc") as String?)?.toIntOrNull() ?: 1
        versionName = "1.0." + versionCode
    }

    buildFeatures { buildConfig = true }

    signingConfigs {
        create("ci") {
            storeFile = file("keystore.jks")
            storePassword = "whalepet123"
            keyAlias = "whalepet"
            keyPassword = "whalepet123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("ci")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("ci")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
