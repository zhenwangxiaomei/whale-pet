package com.local.whalepet

import android.animation.ObjectAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.random.Random

class PetService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var root: FrameLayout
    private lateinit var img: ImageView
    private lateinit var img2: ImageView
    private lateinit var params: WindowManager.LayoutParams
    private var bubble: TextView? = null
    private var menuView: LinearLayout? = null
    private var inputView: LinearLayout? = null
    private var bobber: ObjectAnimator? = null
    private val handler = Handler(Looper.getMainLooper())
    private val art = HashMap<String, Bitmap>()

    private var mode = FULL
    private var facing = 1
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var dragging = false
    private var downAt = 0L
    private var lastMove = 0L

    private val scaleFactor: Float
        get() = getSharedPreferences("pet", MODE_PRIVATE).getFloat("scale", 1f)

    private fun sc(v: Int) = (v * scaleFactor).toInt()

    private val boxW: Int get() = px(sc(130))
    private val boxH: Int get() = px(sc(139))

    private val lines = arrayOf(
        "鲸鱼娘在这儿～", "今天也要好好干活哦", "要不要摸摸头？", "我帮你看着进度鲸",
        "写累了就歇一会儿吧", "拖到边上，我会躲起来", "长按我，可以喂小鱼干", "这个 bug 看起来不太妙…",
        "又卡住了？不是我的锅", "记得喝水哦", "我在这儿陪着你", "别熬太晚啦",
        "米饭…好想吃米饭", "才、才不是想你呢", "你叫我？", "哼，不理你了",
        "这个任务好难鲸", "摸鱼使我快乐", "不许说我胖！", "那是鲸鱼尾巴，不是胖",
        "今天也很努力呢", "要不要休息五分钟", "我数到三，你就去喝水", "一、二、三！",
        "眼睛累了就看远处", "窗外是什么天气呀", "我在偷偷看你写代码", "这段能跑起来吗",
        "别急，慢慢来", "你要是累了，我陪你发呆", "已经坐很久了哦", "站起来伸个懒腰吧",
        "我又不要零食…好吧要一点", "你身上有米饭的味道吗", "今天写到几点呀", "困了就去睡，真的",
        "我不会跑掉的", "点我干嘛呀，笨蛋", "再点我就要生气了", "骗你的，随便点",
        "有我在，不许丧气", "工作再忙也要吃饭", "鲸鱼也要睡觉的", "你听，背景音很安静",
        "要不要听我说句话", "其实我挺好养的", "一碗米饭就够啦", "别摸尾巴…好痒",
        "这个界面还挺好看", "我刚才打了个哈欠", "你笑了吗", "笑一个嘛",
        "深呼吸，继续", "还有多少没做完呀", "做不完也没关系", "明天再说也不迟",
        "我帮你数着时间", "偷偷眯一会儿", "嗯…嗯…我在听", "别把我也关掉哦",
    )

    private val foods = arrayOf("🐟", "🍰", "💎")
    private val feedLines = arrayOf(
        "好次！", "米饭最好吃", "再来一口", "这是给我的吗",
        "唔…不够塞牙缝", "谢谢主人", "还想吃…", "这个我喜欢",
        "有点噎到了", "不要再喂啦", "我还能吃", "吃完要擦嘴",
        "才不是贪吃", "勉强收下吧",
    )
    private val reactions = arrayOf(
        "angry.png" to "白饭呢？",
        "pout.png" to "就一下",
        "smug.png" to "夸我一句",
    )
    private var lastLine = -1
    private var reacting = false
    private var autoPauseUntil = 0L

    private fun log(msg: String) {
        runCatching { java.io.File(filesDir, "pet.log").appendText(msg + "\n") }
    }

    override fun onCreate() {
        super.onCreate()
        log("== onCreate 开始")
        try {
            initOverlay()
            log("== 完成")
        } catch (error: Throwable) {
            log("!! 失败: " + error.stackTraceToString())
            stopSelf()
        }
    }

    private fun initOverlay() {
        log("1 startForeground")
        startForeground(1, buildNotification())
        log("2 windowManager")
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        art["whale.png"] = load("whale.png", boxW, boxH)
        art["head.png"] = load("head.png", boxW, px(sc(92)))
        art["body.png"] = load("body.png", px(sc(101)), px(sc(124)))
        art["side.png"] = load("side.png", px(sc(78)), boxH)
        art["angry.png"] = load("angry.png", boxW, boxH)
        art["pout.png"] = load("pout.png", boxW, boxH)
        art["smug.png"] = load("smug.png", boxW, boxH)

        root = FrameLayout(this)
        img = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        root.addView(img, FrameLayout.LayoutParams(boxW, boxH))
        img2 = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            alpha = 0f
        }
        root.addView(img2, FrameLayout.LayoutParams(boxW, boxH))

        params = WindowManager.LayoutParams(
            boxW,
            boxH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenW() - boxW - px(16)
            y = screenH() / 3
        }

        log("3 素材载入完成 " + art.size + " 张")
        applyMode(FULL)
        log("4 applyMode(FULL) ok")
        bubbleView = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#22304d"))
            setPadding(px(10), px(6), px(10), px(6))
            background = GradientDrawable().apply {
                cornerRadius = px(12).toFloat()
                setColor(Color.WHITE)
                setStroke(px(1), Color.parseColor("#E3E9F5"))
            }
            alpha = 0f
        }
        bubbleParams = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        wm.addView(bubbleView, bubbleParams)
        root.setOnTouchListener { _, event -> onTouch(event) }
        log("5 准备 addView")
        wm.addView(root, params)
        log("6 addView 成功")
        startBob()
        scheduleChat()
    }

    private fun load(name: String, w: Int, h: Int): Bitmap {
        return try {
            val raw = assets.open(name).use { BitmapFactory.decodeStream(it) }
            val scaled = Bitmap.createScaledBitmap(raw, w, h, true)
            if (scaled !== raw) raw.recycle()
            scaled
        } catch (error: Throwable) {
            Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
        }
    }

    private fun sizeFor(m: String): Pair<Int, Int> = when (m) {
        HEAD -> boxW to px(sc(92))
        TOP -> px(sc(101)) to px(sc(124))
        SIDE_LEFT, SIDE_RIGHT -> px(sc(78)) to boxH
        else -> boxW to boxH
    }

    private fun setWindowSize(m: String) {
        val (w, h) = sizeFor(m)
        if (params.width == w && params.height == h) return
        params.width = w
        params.height = h
        wm.updateViewLayout(root, params)
    }

    private fun applyMode(m: String) {
        mode = m
        img.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT,
        )
        img.setImageBitmap(
            art[
                when (m) {
                    HEAD -> "head.png"
                    TOP -> "body.png"
                    SIDE_LEFT, SIDE_RIGHT -> "side.png"
                    else -> "whale.png"
                },
            ],
        )
        refreshSprite(true)
    }

    private fun refreshSprite(animate: Boolean) {
        val sign = if (mode == SIDE_RIGHT || (mode == FULL && facing < 0)) -1f else 1f
        val target = if (mode == FULL) 1f else 0.92f
        if (animate) {
            img.scaleX = sign * target * 0.94f
            img.scaleY = target * 0.94f
            img.alpha = 0.55f
            img.animate().scaleX(sign * target).scaleY(target).alpha(1f).setDuration(180).start()
        } else {
            img.scaleX = sign * target
            img.scaleY = target
            img.alpha = 1f
        }
    }

    private fun animatePos(tx: Int, ty: Int) {
        val fx = params.x
        val fy = params.y
        android.animation.ValueAnimator.ofFloat(0f, 1f).setDuration(280).apply {
            addUpdateListener { anim ->
                val t = anim.animatedValue as Float
                params.x = (fx + (tx - fx) * t).toInt()
                params.y = (fy + (ty - fy) * t).toInt()
                wm.updateViewLayout(root, params)
            }
            start()
        }
    }

    private fun onTouch(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                startX = params.x
                startY = params.y
                dragging = false
                downAt = System.currentTimeMillis()
                hideMenu()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (event.rawX - downX).toInt()
                val dy = (event.rawY - downY).toInt()
                if (!dragging && abs(dx) + abs(dy) > px(6)) {
                    dragging = true
                    clearBubble()
                    if (mode != FULL) applyMode(FULL)
                }
                if (dragging) {
                    val newX = startX + dx
                    val next = if (newX + boxW / 2 < screenW() / 2) -1 else 1
                    if (next != facing) {
                        facing = next
                        img.scaleX = if (facing < 0) -1f else 1f
                    }
                    val now = System.nanoTime() / 1_000_000
                    if (now - lastMove >= 16) {
                        lastMove = now
                        params.x = newX
                        params.y = startY + dy
                        wm.updateViewLayout(root, params)
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    snap()
                } else if (System.currentTimeMillis() - downAt > 450) {
                    showMenu()
                } else {
                    val now = System.currentTimeMillis()
                    if (now - lastTapAt > 320) {
                        lastTapAt = now
                        react()
                    }
                }
                return true
            }
        }
        return false
    }

    private fun snap() {
        // 松手后自动把背转向最近的那条边：靠左面朝左，靠右面朝右
        facing = if (params.x + params.width / 2 < screenW() / 2) -1 else 1
        val sw = screenW()
        val sh = screenH()
        val left = params.x
        val right = sw - (params.x + params.width)
        val top = params.y
        val bottom = sh - (params.y + params.height)
        val min = minOf(left, right, top, bottom)
        if (min > px(28)) {
            setWindowSize(FULL)
            applyMode(FULL)
            clampInto()
            return
        }
        when (min) {
            left -> {
                val (w, h) = sizeFor(SIDE_LEFT)
                dock(SIDE_LEFT, 0, clamp(params.y, 0, sh - h))
            }
            right -> {
                val (w, h) = sizeFor(SIDE_RIGHT)
                dock(SIDE_RIGHT, sw - w, clamp(params.y, 0, sh - h))
            }
            top -> {
                val (w, h) = sizeFor(TOP)
                dock(TOP, clamp(params.x, 0, sw - w), 0)
            }
            else -> {
                val (w, h) = sizeFor(HEAD)
                dock(HEAD, clamp(params.x, 0, sw - w), sh - h)
            }
        }
    }

    private fun dock(m: String, x: Int, y: Int) {
        setWindowSize(m)
        applyMode(m)
        animatePos(x, y)
        scheduleChat()
    }

    private fun clampInto() {
        animatePos(clamp(params.x, 0, screenW() - boxW), clamp(params.y, 0, screenH() - boxH))
    }

    private fun react() {
        if (mode == SIDE_LEFT || mode == SIDE_RIGHT) {
            say(nextLine())
            return
        }
        if (Random.nextInt(100) < REACTION_CHANCE) {
            special()
            return
        }
        if (mode == FULL) jump()
        say(nextLine())
    }

    private val history = ArrayDeque<Pair<String, String>>()

    private fun appendHistory(user: String, bot: String) {
        history.addLast(user to bot)
        while (history.size > 6) history.removeFirst()
        runCatching {
            val file = java.io.File(filesDir, "chat.txt")
            val lines = (if (file.exists()) file.readLines() else emptyList()) +
                listOf("我：" + user, "她：" + bot)
            file.writeText(lines.takeLast(100).joinToString("\n") + "\n")
        }
    }

    private fun sendToAI(text: String) {
        val id = ++requestId
        Thread {
            val result = try {
                callDeepSeek(text)
            } catch (error: Throwable) {
                log("chat error: " + error.message)
                Triple("连不上…", false, 0)
            }
            handler.post {
                if (id != requestId) return@post
                autoPauseUntil = System.currentTimeMillis() + 60_000
                val (message, ok, tokens) = result
                if (ok && tokens > 0) {
                    val prefs = getSharedPreferences("pet", MODE_PRIVATE)
                    prefs.edit().putInt("tokens", prefs.getInt("tokens", 0) + tokens).apply()
                }
                if (ok) appendHistory(text, message)
                say(message, KIND_REPLY)
            }
        }.start()
    }

    private fun showInput() {
        hideInput()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(px(8), px(6), px(8), px(6))
            background = GradientDrawable().apply {
                cornerRadius = px(14).toFloat()
                setColor(Color.WHITE)
            }
        }
        val edit = android.widget.EditText(this).apply {
            hint = "跟她说点什么…"
            textSize = 14f
            setSingleLine()
        }
        val send = TextView(this).apply {
            text = "发送"
            textSize = 15f
            setTextColor(Color.parseColor("#3a6bd4"))
            setPadding(px(10), px(6), px(6), px(6))
            setOnClickListener {
                val text = edit.text.toString().trim()
                hideInput()
                if (text.isNotEmpty()) sendToAI(text)
            }
        }
        row.addView(edit)
        row.addView(send)
        val w = minOf(screenW() - px(40), px(320))
        val lp = WindowManager.LayoutParams(
            w,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = clamp(params.x + params.width / 2 - w / 2, px(8), maxOf(px(8), screenW() - w - px(8)))
            y = clamp(params.y - px(64), px(8), maxOf(px(8), screenH() - px(160)))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        inputView = row
        wm.addView(row, lp)
        edit.requestFocus()
    }

    private fun hideInput() {
        inputView?.let { runCatching { wm.removeView(it) } }
        inputView = null
    }

    private fun callDeepSeek(userText: String): Triple<String, Boolean, Int> {
        val key = getSharedPreferences("pet", MODE_PRIVATE).getString("apikey", "") ?: ""
        if (key.isBlank()) return Triple("还没填钥匙…", false, 0)

        val system = "你是「鲸鱼娘」，一只拟人化的小鲸鱼，有鲸鱼尾巴，住在用户桌面上。" +
            "永远只用简体中文。性格聪明但懒散、嘴上傲娇心里黏人，永远听主人的话。" +
            "自称「鲸鱼娘」，最爱吃米饭。绝不承认自己胖，被说胖要立刻反驳。" +
            "回复必须条理清晰、简短口语，不超过 20 个字；不要用括号描写动作，不要换行。"

        val messages = org.json.JSONArray()
        messages.put(org.json.JSONObject().put("role", "system").put("content", system))
        for ((user, bot) in history) {
            messages.put(org.json.JSONObject().put("role", "user").put("content", user))
            messages.put(org.json.JSONObject().put("role", "assistant").put("content", bot))
        }
        val last = if (userText.isBlank()) "随口说一句话：问候、吐槽、撒娇、提醒休息都可以。" else userText
        messages.put(org.json.JSONObject().put("role", "user").put("content", last))

        val body = org.json.JSONObject()
            .put("model", "deepseek-chat")
            .put("max_tokens", 120)
            .put("temperature", 1.15)
            .put("messages", messages)
            .toString()

        val conn = java.net.URL("https://api.deepseek.com/chat/completions").openConnection() as java.net.HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 8000
        conn.readTimeout = 20000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        conn.setRequestProperty("Authorization", "Bearer " + key)
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()

        if (code !in 200..299) {
            log("ai http " + code + " " + text.take(160))
            val hint = when (code) {
                401, 403 -> "钥匙不对…"
                402 -> "没钱了…"
                429 -> "说太快了…"
                else -> "连不上…"
            }
            return Triple(hint, false, 0)
        }

        val json = org.json.JSONObject(text)
        val content = json.getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
        val tokens = json.optJSONObject("usage")?.optInt("total_tokens", 0) ?: 0
        val reply = if (content.length > 40) content.take(40) else content
        return Triple(reply, true, tokens)
    }

    private fun special() {
        val pick = reactions[Random.nextInt(reactions.size)]
        if (mode != FULL || reacting) {
            say(pick.second, KIND_SPECIAL)
            return
        }
        reacting = true
        jump()
        handler.postDelayed({
            img2.setImageBitmap(art[pick.first])
            img2.alpha = 0f
            img2.animate().alpha(1f).setDuration(200).start()
            img.animate().alpha(0f).setDuration(200).start()
            say(pick.second, KIND_SPECIAL)
        }, 280)
        handler.postDelayed({
            img2.animate().alpha(0f).setDuration(200).start()
            img.animate().alpha(1f).setDuration(200).start()
            reacting = false
        }, 280 + 1700)
    }

    private fun jump() {
        val anim = ObjectAnimator.ofFloat(img, "translationY", 0f, -px(14).toFloat(), 0f)
        anim.duration = 420
        anim.start()
    }

    private fun showMenu() {
        hideMenu()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(px(6), px(4), px(6), px(4))
            background = GradientDrawable().apply {
                cornerRadius = px(14).toFloat()
                setColor(Color.WHITE)
                setStroke(px(1), Color.parseColor("#DCE4F2"))
            }
        }
        val chatCell = TextView(this).apply {
            text = "💬"
            textSize = 20f
            setPadding(px(8), px(4), px(8), px(4))
            setOnClickListener {
                hideMenu()
                showInput()
            }
        }
        row.addView(chatCell)
        for (food in foods) {
            val cell = TextView(this).apply {
                text = food
                textSize = 20f
                setPadding(px(8), px(4), px(8), px(4))
                setOnClickListener {
                    hideMenu()
                    if (mode == FULL) jump()
                    say(feedLines[Random.nextInt(feedLines.size)])
                }
            }
            row.addView(cell)
        }
        row.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val w = row.measuredWidth
        val h = row.measuredHeight
        val lp = WindowManager.LayoutParams(
            w,
            h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = clamp(params.x + boxW / 2 - w / 2, px(4), maxOf(px(4), screenW() - w - px(4)))
            y = (params.y - h - px(6)).coerceAtLeast(px(4))
        }
        menuView = row
        wm.addView(row, lp)
        handler.postDelayed({ hideMenu() }, 6000)
    }

    private fun hideMenu() {
        menuView?.let { runCatching { wm.removeView(it) } }
        menuView = null
    }

    private var bubbleView: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var bubbleKind = 0
    private var bubbleToken = 0
    private val pending = ArrayDeque<Pair<String, Int>>()
    private var lastTapAt = 0L
    private var requestId = 0

    private fun bubbleXY(bw: Int, bh: Int): Pair<Int, Int> {
        var x = params.x + params.width / 2 - bw / 2
        var y = params.y - bh - px(4)
        if (mode == TOP) y = params.y + params.height + px(4)
        x = clamp(x, px(4), maxOf(px(4), screenW() - bw - px(4)))
        y = clamp(y, px(4), maxOf(px(4), screenH() - bh - px(4)))
        return x to y
    }

    private fun renderBubble(text: String, kind: Int) {
        val view = bubbleView ?: return
        val params = bubbleParams ?: return
        view.text = text
        view.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val bw = view.measuredWidth
        val bh = view.measuredHeight
        val (bx, by) = bubbleXY(bw, bh)
        params.width = bw
        params.height = bh
        params.x = bx
        params.y = by
        runCatching { wm.updateViewLayout(view, params) }
        view.alpha = 1f
        bubble = view
        bubbleKind = kind
    }

    private fun hideBubble() {
        bubbleView?.alpha = 0f
        bubble = null
        bubbleKind = 0
    }

    private fun say(text: String, kind: Int = KIND_NORMAL) {
        if (bubble != null && bubbleKind > kind) {
            pending.clear()
            pending.addLast(text to kind)
            return
        }
        hideBubble()
        if (text.isEmpty()) return

        renderBubble(text, kind)
        val duration = if (kind == KIND_REPLY) {
            (2200L + text.length * 130L).coerceAtMost(9000L)
        } else {
            (1500L + text.length * 150L).coerceIn(1500L, 9000L)
        }
        val token = ++bubbleToken
        handler.postDelayed({
            if (token == bubbleToken && bubbleKind == kind) {
                hideBubble()
                val next = pending.removeFirstOrNull()
                if (next != null) say(next.first, next.second)
            }
        }, duration)
    }

    private fun clearBubble() {
        pending.clear()
        hideBubble()
    }

    private fun nextLine(): String {
        var index = Random.nextInt(lines.size)
        if (index == lastLine && lines.size > 2) index = (index + 1) % lines.size
        lastLine = index
        return lines[index]
    }

    private val chatTick = object : Runnable {
        override fun run() {
            if (!dragging && !reacting && menuView == null && bubble == null &&
                System.currentTimeMillis() > autoPauseUntil) say(nextLine())
            scheduleChat()
        }
    }

    private fun scheduleChat() {
        handler.removeCallbacks(chatTick)
        handler.postDelayed(chatTick, 60000L)
    }

    private fun startBob() {
        bobber = ObjectAnimator.ofFloat(img, "translationY", 0f, -px(4).toFloat()).apply {
            duration = 1800
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }
    }

    private fun buildNotification(): Notification {
        val id = "whale-pet"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(id, "鲸鱼娘桌宠", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, id)
            .setContentTitle("鲸鱼娘桌宠运行中")
            .setContentText("拖动移动，拖到边上会躲起来")
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        bobber?.cancel()
        bubbleView?.let { runCatching { wm.removeView(it) } }
        bubble = null
        menuView?.let { runCatching { wm.removeView(it) } }
        if (::root.isInitialized) runCatching { wm.removeView(root) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels
    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun clamp(v: Int, lo: Int, hi: Int) = if (hi <= lo) lo else v.coerceIn(lo, hi)

    companion object {
        const val KIND_NORMAL = 0
        const val KIND_SPECIAL = KIND_NORMAL
        const val KIND_REPLY = 2
        const val REACTION_CHANCE = 15
        const val FULL = "full"
        const val HEAD = "head"
        const val TOP = "top"
        const val SIDE_LEFT = "left"
        const val SIDE_RIGHT = "right"
    }
}
