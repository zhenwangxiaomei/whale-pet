package com.local.whalepet

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var pages: LinearLayout
    private lateinit var home: LinearLayout
    private lateinit var historyPage: LinearLayout
    private lateinit var logPage: LinearLayout
    private lateinit var status: TextView
    private lateinit var historyText: TextView
    private lateinit var logText: TextView
    private var pad = 16
    private val ui = android.os.Handler(android.os.Looper.getMainLooper())
    private var updateUrl: String? = null
    private lateinit var updateBtn: Button
    private lateinit var tokenLabel: TextView
    private lateinit var sizeLabel: TextView
    private lateinit var sizeBar: SeekBar
    private lateinit var balanceLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Thread.setDefaultUncaughtExceptionHandler { _, error ->
            runCatching {
                java.io.File(filesDir, "crash.txt").writeText(error.stackTraceToString())
            }
            android.os.Process.killProcess(android.os.Process.myPid())
        }

        pad = (16 * resources.displayMetrics.density).toInt()
        prefs = getSharedPreferences("pet", MODE_PRIVATE)

        home = buildHome()
        historyPage = buildTextPage("对话记录") { historyText = it }
        logPage = buildTextPage("日志") { logText = it }

        pages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            addView(home)
            addView(historyPage)
            addView(logPage)
        }
        setContentView(pages)
        show(home)
    }

    private fun show(page: LinearLayout) {
        for (p in listOf(home, historyPage, logPage)) p.visibility = if (p === page) View.VISIBLE else View.GONE
    }

    private fun label(text: String, size: Float = 14f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        gravity = Gravity.CENTER
        setPadding(0, pad / 2, 0, pad / 2)
    }

    private fun buildHome(): LinearLayout {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun section(text: String) {
            page.addView(TextView(this).apply {
                this.text = text
                textSize = 12f
                setTextColor(Color.parseColor("#8892a6"))
                setPadding(0, pad, 0, pad / 3)
            })
        }

        fun row(vararg views: View) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (view in views) {
                line.addView(
                    view,
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                        .apply { marginEnd = pad / 3 },
                )
            }
            page.addView(line)
        }

        fun full(view: View) {
            page.addView(
                view,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                ),
            )
        }

        // 标题
        full(TextView(this).apply {
            text = "鲸鱼娘桌宠 · 构建 " + BuildConfig.VERSION_CODE
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad / 2)
        })

        // 更新（有新版才显示）
        updateBtn = Button(this).apply {
            visibility = View.GONE
            setOnClickListener { downloadAndInstall() }
        }
        full(updateBtn)

        // 状态
        status = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad)
        }
        full(status)

        // ① 权限
        section("① 权限")
        val permBtn = Button(this).apply {
            text = "授予悬浮窗权限"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        full(permBtn)

        // ② 大小
        section("② 桌宠大小")
        sizeLabel = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER_VERTICAL
            minWidth = pad * 4
        }
        sizeBar = SeekBar(this).apply {
            max = 160
            progress = ((prefs.getFloat("scale", 1f) * 100).toInt() - 40).coerceIn(0, 160)
        }
        renderSize()
        val sizeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sizeRow.addView(sizeLabel, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        sizeRow.addView(sizeBar, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        full(sizeRow)
        sizeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) = renderSize()
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {
                prefs.edit().putFloat("scale", (sizeBar.progress + 40) / 100f).apply()
                stopService(Intent(this@MainActivity, PetService::class.java))
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startForegroundService(Intent(this@MainActivity, PetService::class.java))
                    status.text = "大小已保存，桌宠已按新尺寸重启"
                } else {
                    status.text = "大小已保存，启动时生效"
                }
            }
        })
        // ③ AI 对话
        section("③ AI 对话（DeepSeek）")
        val keyInput = EditText(this).apply {
            hint = "sk-...（可留空，留空只用本地台词）"
            setText(prefs.getString("apikey", "") ?: "")
            textSize = 13f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
        }
        val keyRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        keyRow.addView(keyInput, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        keyRow.addView(
            Button(this).apply {
                text = "保存"
                setOnClickListener {
                    prefs.edit().putString("apikey", keyInput.text.toString().trim()).apply()
                    status.text = if (keyInput.text.isBlank()) "key 已清空，只用本地台词" else "key 已保存"
                }
            },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { marginStart = pad / 3 },
        )
        full(keyRow)

        tokenLabel = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, 0)
        }
        renderTokens()

        balanceLabel = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER
            text = "余额：—"
        }
        row(tokenLabel, balanceLabel)

        row(
            Button(this).apply {
                text = "刷新余额"
                setOnClickListener { checkBalance() }
            },
            Button(this).apply {
                text = "token 清零"
                setOnClickListener {
                    prefs.edit().putInt("tokens", 0).apply()
                    renderTokens()
                }
            },
        )

        // ④ 运行
        section("④ 运行")
        full(Button(this).apply {
            text = "启动桌宠"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    status.text = "还没给悬浮窗权限"
                    return@setOnClickListener
                }
                startForegroundService(Intent(this@MainActivity, PetService::class.java))
                status.text = "已启动，回桌面看看"
            }
        })
        full(Button(this).apply {
            text = "停止桌宠"
            setOnClickListener {
                stopService(Intent(this@MainActivity, PetService::class.java))
                status.text = "已停止"
            }
        })

        // ⑤ 页面
        section("⑤ 查看")
        val historyBtn = Button(this).apply {
            text = "对话记录"
            setOnClickListener {
                historyText.text = readText("chat.txt", "还没有对话记录")
                show(historyPage)
            }
        }
        val logBtn = Button(this).apply {
            text = "日志"
            setOnClickListener {
                logText.text = readText("pet.log", "还没有日志")
                show(logPage)
            }
        }
        row(historyBtn, logBtn)

        return page
    }

    private fun buildTextPage(title: String, bind: (TextView) -> Unit): LinearLayout {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            visibility = View.GONE
        }

        val head = TextView(this).apply {
            text = title
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad)
        }

        val body = TextView(this).apply {
            textSize = 11f
            setTextIsSelectable(true)
            setPadding(pad / 2, pad / 3, pad / 2, pad / 3)
            movementMethod = ScrollingMovementMethod()
        }
        bind(body)

        val scroll = ScrollView(this).apply {
            addView(body)
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val backBtn = Button(this).apply {
            text = "返回"
            setOnClickListener { show(home) }
        }
        val clearBtn = Button(this).apply {
            text = "清空"
            setOnClickListener {
                val name = if (title == "日志") "pet.log" else "chat.txt"
                runCatching { java.io.File(filesDir, name).delete() }
                body.text = "已清空"
            }
        }
        row.addView(backBtn)
        row.addView(clearBtn)

        page.addView(head)
        page.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        page.addView(row)
        return page
    }

    private fun renderSize() {
        sizeLabel.text = "大小：" + (sizeBar.progress + 40) + "%"
    }

    private fun renderTokens() {
        tokenLabel.text = "AI 对话已用 token：" + prefs.getInt("tokens", 0)
    }

    private fun readText(name: String, empty: String): String {
        val file = java.io.File(filesDir, name)
        return if (file.exists()) file.readText().takeLast(4000) else empty
    }

    private fun checkBalance() {
        val key = prefs.getString("apikey", "") ?: ""
        if (key.isBlank()) {
            balanceLabel.text = "余额：未填 key"
            return
        }
        Thread {
            val info = runCatching {
                val conn = java.net.URL("https://api.deepseek.com/user/balance")
                    .openConnection() as java.net.HttpURLConnection
                conn.setRequestProperty("Authorization", "Bearer " + key)
                conn.connectTimeout = 8000
                conn.readTimeout = 10000
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val infos = org.json.JSONObject(text).getJSONArray("balance_infos")
                if (infos.length() > 0) {
                    val item = infos.getJSONObject(0)
                    item.getString("currency") + " " + item.getString("total_balance")
                } else {
                    "0"
                }
            }.getOrNull()

            ui.post {
                balanceLabel.text = if (info == null) "余额：查询失败" else "余额：" + info
            }
        }.start()
    }

    private fun checkUpdate() {
        Thread {
            val info = runCatching {
                val conn = java.net.URL("https://api.github.com/repos/zhenwangxiaomei/whale-pet/releases/latest")
                    .openConnection() as java.net.HttpURLConnection
                conn.setRequestProperty("Accept", "application/vnd.github+json")
                conn.connectTimeout = 8000
                conn.readTimeout = 10000
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val json = org.json.JSONObject(text)
                val number = json.getString("tag_name").removePrefix("v").toIntOrNull() ?: 0
                val assets = json.getJSONArray("assets")
                val url = if (assets.length() > 0) assets.getJSONObject(0).getString("browser_download_url") else ""
                number to url
            }.getOrNull() ?: return@Thread

            ui.post {
                if (info.first > BuildConfig.VERSION_CODE && info.second.isNotEmpty()) {
                    updateUrl = info.second
                    updateBtn.visibility = View.VISIBLE
                    updateBtn.text = "发现新版本 v" + info.first + "，点击更新"
                }
            }
        }.start()
    }

    private fun downloadAndInstall() {
        val url = updateUrl ?: return
        updateBtn.isEnabled = false
        updateBtn.text = "下载中…"
        Thread {
            val apk = runCatching {
                val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 60000
                val file = java.io.File(cacheDir, "update.apk")
                conn.inputStream.use { input -> file.outputStream().use { input.copyTo(it) } }
                conn.disconnect()
                file
            }.getOrNull()

            ui.post {
                if (apk == null) {
                    updateBtn.isEnabled = true
                    updateBtn.text = "下载失败，重试"
                } else {
                    install(apk)
                }
            }
        }.start()
    }

    private fun install(apk: java.io.File) {
        runCatching {
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.files", apk)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        }.onFailure {
            updateBtn.isEnabled = true
            updateBtn.text = "请先允许「安装未知应用」"
            runCatching {
                startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        status.setTextSize(14f)
        status.text =
            if (Settings.canDrawOverlays(this)) "悬浮窗权限：已授予" else "悬浮窗权限：未授予"
        tokenLabel.text = "AI 对话已用 token：" + prefs.getInt("tokens", 0)
        checkBalance()
        checkUpdate()
    }
}
