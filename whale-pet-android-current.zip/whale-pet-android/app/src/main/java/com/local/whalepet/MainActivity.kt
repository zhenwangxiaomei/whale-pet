package com.local.whalepet

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 崩溃记录：写到 filesDir/crash.txt，下次打开 App 直接显示
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                java.io.File(filesDir, "crash.txt").writeText(
                    error.stackTraceToString(),
                )
            }
            android.os.Process.killProcess(android.os.Process.myPid())
        }

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 3, pad, pad)
            setBackgroundColor(Color.WHITE)
        }
        val title = TextView(this).apply {
            text = "鲸鱼娘桌宠"
            textSize = 22f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad * 2)
        }
        val permBtn = Button(this).apply {
            text = "① 授予悬浮窗权限"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"),
                    ),
                )
            }
        }
        val sizeLabel = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
        }
        val prefs = getSharedPreferences("pet", MODE_PRIVATE)
        val sizeBar = android.widget.SeekBar(this).apply {
            max = 160
            progress = ((prefs.getFloat("scale", 1f) * 100).toInt() - 40).coerceIn(0, 160)
        }
        fun renderSize() {
            sizeLabel.text = "大小：" + (sizeBar.progress + 40) + "%"
        }
        renderSize()
        sizeBar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: android.widget.SeekBar?, value: Int, fromUser: Boolean) {
                renderSize()
            }

            override fun onStartTrackingTouch(bar: android.widget.SeekBar?) {}

            override fun onStopTrackingTouch(bar: android.widget.SeekBar?) {
                prefs.edit().putFloat("scale", (sizeBar.progress + 40) / 100f).apply()
                stopService(Intent(this@MainActivity, PetService::class.java))
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startForegroundService(Intent(this@MainActivity, PetService::class.java))
                    status.text = "大小已保存，桌宠已按新尺寸重启"
                } else {
                    status.text = "大小已保存，启动时会生效"
                }
            }
        })

        val startBtn = Button(this).apply {
            text = "② 启动桌宠"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    status.text = "还没给悬浮窗权限"
                    return@setOnClickListener
                }
                startForegroundService(Intent(this@MainActivity, PetService::class.java))
                status.text = "已启动，回桌面看看"
            }
        }
        val stopBtn = Button(this).apply {
            text = "停止桌宠"
            setOnClickListener {
                stopService(Intent(this@MainActivity, PetService::class.java))
                status.text = "已停止"
            }
        }
        listOf(title, status, permBtn, sizeLabel, sizeBar, startBtn, stopBtn).forEach { root.addView(it) }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val petLog = java.io.File(filesDir, "pet.log")
        val crash = java.io.File(filesDir, "crash.txt")
        if (petLog.exists()) {
            status.text = petLog.readText().takeLast(900)
            status.setTextSize(10f)
            petLog.delete()
        } else if (crash.exists()) {
            status.text = "上次崩溃：\n" + crash.readText().take(700)
            status.setTextSize(11f)
            crash.delete()
        } else {
            status.text =
                if (Settings.canDrawOverlays(this)) "悬浮窗权限：已授予" else "悬浮窗权限：未授予"
        }
    }
}
