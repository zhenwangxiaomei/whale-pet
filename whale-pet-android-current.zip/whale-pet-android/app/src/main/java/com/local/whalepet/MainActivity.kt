package com.local.whalepet

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var pages: LinearLayout
    private lateinit var home: LinearLayout
    private lateinit var historyPage: LinearLayout
    private lateinit var logPage: LinearLayout
    private lateinit var status: TextView
    private lateinit var historyText: TextView
    private lateinit var logText: TextView
    private var pad = 16

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Thread.setDefaultUncaughtExceptionHandler { _, error ->
            runCatching {
                java.io.File(filesDir, "crash.txt").writeText(error.stackTraceToString())
            }
            android.os.Process.killProcess(android.os.Process.myPid())
        }

        pad = (16 * resources.displayMetrics.density).toInt()
        prefs = getSharedPreferences("pet", MODE_PRIVATE)

        home = buildHome()
        historyPage = buildTextPage("对话记录") { historyText = it }
        logPage = buildTextPage("日志") { logText = it }

        pages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            addView(home)
            addView(historyPage)
            addView(logPage)
        }
        setContentView(pages)
        show(home)
    }

    private fun show(page: LinearLayout) {
        for (p in listOf(home, historyPage, logPage)) p.visibility = if (p === page) View.VISIBLE else View.GONE
    }

    private fun label(text: String, size: Float = 14f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        gravity = Gravity.CENTER
        setPadding(0, pad / 2, 0, pad / 2)
    }

    private fun buildHome(): LinearLayout {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "鲸鱼娘桌宠 v20"
            textSize = 22f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad * 2)
        }

        val permBtn = Button(this).apply {
            text = "① 授予悬浮窗权限"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }

        val keyInput = EditText(this).apply {
            hint = "sk-...（DeepSeek API key，可留空）"
            setText(prefs.getString("apikey", "") ?: "")
            textSize = 13f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
        }
        val keySave = Button(this).apply {
            text = "保存 key"
            setOnClickListener {
                prefs.edit().putString("apikey", keyInput.text.toString().trim()).apply()
                status.text = if (keyInput.text.isBlank()) "key 已清空，改用本地台词" else "key 已保存，点她会用 AI 说话"
            }
        }

        val sizeLabel = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
        }
        val sizeBar = SeekBar(this).apply {
            max = 160
            progress = ((prefs.getFloat("scale", 1f) * 100).toInt() - 40).coerceIn(0, 160)
        }
        fun renderSize() {
            sizeLabel.text = "大小：" + (sizeBar.progress + 40) + "%"
        }
        renderSize()
        sizeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) = renderSize()
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {
                prefs.edit().putFloat("scale", (sizeBar.progress + 40) / 100f).apply()
                stopService(Intent(this@MainActivity, PetService::class.java))
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startForegroundService(Intent(this@MainActivity, PetService::class.java))
                    status.text = "大小已保存，桌宠已按新尺寸重启"
                } else {
                    status.text = "大小已保存，启动时生效"
                }
            }
        })

        val startBtn = Button(this).apply {
            text = "② 启动桌宠"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    status.text = "还没给悬浮窗权限"
                    return@setOnClickListener
                }
                startForegroundService(Intent(this@MainActivity, PetService::class.java))
                status.text = "已启动，回桌面看看"
            }
        }
        val stopBtn = Button(this).apply {
            text = "停止桌宠"
            setOnClickListener {
                stopService(Intent(this@MainActivity, PetService::class.java))
                status.text = "已停止"
            }
        }

        val navRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val historyBtn = Button(this).apply {
            text = "对话记录"
            setOnClickListener {
                historyText.text = readText("chat.txt", "还没有对话记录")
                show(historyPage)
            }
        }
        val logBtn = Button(this).apply {
            text = "日志"
            setOnClickListener {
                logText.text = readText("pet.log", "还没有日志")
                show(logPage)
            }
        }
        navRow.addView(historyBtn)
        navRow.addView(logBtn)

        listOf(title, status, permBtn, keyInput, keySave, sizeLabel, sizeBar, startBtn, stopBtn, navRow)
            .forEach { page.addView(it) }
        return page
    }

    private fun buildTextPage(title: String, bind: (TextView) -> Unit): LinearLayout {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            visibility = View.GONE
        }

        val head = TextView(this).apply {
            text = title
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad)
        }

        val body = TextView(this).apply {
            textSize = 11f
            setTextIsSelectable(true)
            setPadding(pad / 2, pad / 3, pad / 2, pad / 3)
            movementMethod = ScrollingMovementMethod()
        }
        bind(body)

        val scroll = ScrollView(this).apply {
            addView(body)
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val backBtn = Button(this).apply {
            text = "返回"
            setOnClickListener { show(home) }
        }
        val clearBtn = Button(this).apply {
            text = "清空"
            setOnClickListener {
                val name = if (title == "日志") "pet.log" else "chat.txt"
                runCatching { java.io.File(filesDir, name).delete() }
                body.text = "已清空"
            }
        }
        row.addView(backBtn)
        row.addView(clearBtn)

        page.addView(head)
        page.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        page.addView(row)
        return page
    }

    private fun readText(name: String, empty: String): String {
        val file = java.io.File(filesDir, name)
        return if (file.exists()) file.readText().takeLast(4000) else empty
    }

    override fun onResume() {
        super.onResume()
        status.setTextSize(14f)
        status.text =
            if (Settings.canDrawOverlays(this)) "悬浮窗权限：已授予" else "悬浮窗权限：未授予"
    }
}
