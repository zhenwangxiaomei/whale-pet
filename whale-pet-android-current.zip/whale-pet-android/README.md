# 鲸鱼娘桌宠（Android）

把 DSH 里的那只鲸鱼娘搬到桌面上：系统悬浮窗，浮在任何 App 之上。

## 功能

- 悬浮窗显示立绘，常驻桌面
- 拖动移动，松手自动吸到最近一侧
- 点击：跳一下 + 随机台词
- 通知栏常驻，防止被系统回收

## 构建（二选一）

### A. 电脑 + Android Studio

1. 安装 Android Studio（自带 JDK 17 + SDK）
2. `File → Open`，选这个目录
3. 等 Gradle 同步完，点 ▶ 运行，或在 `Build → Build APK(s)`
4. 产物：`app/build/outputs/apk/debug/app-debug.apk`

### B. GitHub Actions（无需电脑）

1. 新建一个 GitHub 仓库，把这个目录的内容推上去
2. 仓库 `Actions` 页 → Build APK → Run workflow
3. 跑完在 Artifact 里下载 `whale-pet-apk`

## 安装与使用

1. 安装 APK，打开「鲸鱼娘桌宠」
2. 点「① 授予悬浮窗权限」，在系统页面允许
3. 回 App 点「② 启动桌宠」，按 Home 回桌面

## 素材

`app/src/main/assets/` 下四张图与 DSH 插件共用：

- `whale.png` 全身
- `head.png` 探头（暂未接）
- `side.png` 扒墙侧面（暂未接）
- `body.png` 只剩身体（暂未接）

## 还没做

- 贴边躲藏（四边）——逻辑在 DSH 插件里已经跑通，需要把 `metrics/place` 那套搬过来
- 喂食、跟随鼠标、走动
- 开机自启

## 说明

悬浮窗权限是系统级授权，装上后会一直浮在其他 App 上面；不想要就回 App 点「停止桌宠」。
