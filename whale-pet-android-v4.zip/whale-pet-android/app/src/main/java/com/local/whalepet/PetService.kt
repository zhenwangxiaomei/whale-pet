package com.local.whalepet

import android.animation.ObjectAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.random.Random

class PetService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var root: FrameLayout
    private lateinit var img: ImageView
    private lateinit var params: WindowManager.LayoutParams
    private var bubble: TextView? = null
    private var menuView: LinearLayout? = null
    private var bobber: ObjectAnimator? = null
    private val handler = Handler(Looper.getMainLooper())
    private val art = HashMap<String, Bitmap>()

    private var mode = FULL
    private var facing = 1
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var dragging = false
    private var downAt = 0L
    private var lastMove = 0L

    private val boxW: Int get() = px(130)
    private val boxH: Int get() = px(139)

    private val lines = arrayOf(
        "鲸鱼娘在这儿～",
        "今天也要好好干活哦",
        "要不要摸摸头？",
        "我帮你看着进度鲸",
        "写累了就歇一会儿吧",
        "拖到边上，我会躲起来",
        "长按我，可以喂小鱼干",
        "这个 bug 看起来不太妙…",
        "又卡住了？不是我的锅",
        "记得喝水哦",
        "我在这儿陪着你",
        "别熬太晚啦",
    )
    private val foods = arrayOf("🐟", "🍰", "💎")
    private var lastLine = -1

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        art["whale.png"] = load("whale.png", boxW, boxH)
        art["head.png"] = load("head.png", boxW, px(92))
        art["body.png"] = load("body.png", px(101), px(124))
        art["side.png"] = load("side.png", px(78), boxH)

        root = FrameLayout(this)
        img = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        root.addView(img, FrameLayout.LayoutParams(boxW, boxH))

        params = WindowManager.LayoutParams(
            boxW,
            boxH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenW() - boxW - px(16)
            y = screenH() / 3
        }

        applyMode(FULL)
        root.setOnTouchListener { _, event -> onTouch(event) }
        wm.addView(root, params)
        startBob()
        scheduleChat()
    }

    private fun load(name: String, w: Int, h: Int): Bitmap {
        val raw = assets.open(name).use { BitmapFactory.decodeStream(it) }
        val scaled = Bitmap.createScaledBitmap(raw, w, h, true)
        if (scaled !== raw) raw.recycle()
        return scaled
    }

    private fun applyMode(m: String) {
        mode = m
        val lp = FrameLayout.LayoutParams(boxW, boxH)
        when (m) {
            HEAD -> {
                lp.width = boxW
                lp.height = px(92)
                lp.gravity = Gravity.BOTTOM
            }
            TOP -> {
                lp.width = px(101)
                lp.height = px(124)
                lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            }
            SIDE_LEFT, SIDE_RIGHT -> {
                lp.width = px(78)
                lp.height = boxH
                lp.gravity = (if (m == SIDE_LEFT) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL
            }
            else -> lp.gravity = Gravity.CENTER
        }
        img.layoutParams = lp
        img.setImageBitmap(
            art[
                when (m) {
                    HEAD -> "head.png"
                    TOP -> "body.png"
                    SIDE_LEFT, SIDE_RIGHT -> "side.png"
                    else -> "whale.png"
                },
            ],
        )
        img.scaleX = if (m == SIDE_RIGHT || (m == FULL && facing < 0)) -1f else 1f
    }

    private fun onTouch(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                startX = params.x
                startY = params.y
                dragging = false
                downAt = System.currentTimeMillis()
                hideMenu()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (event.rawX - downX).toInt()
                val dy = (event.rawY - downY).toInt()
                if (!dragging && abs(dx) + abs(dy) > px(6)) {
                    dragging = true
                    if (mode != FULL) applyMode(FULL)
                }
                if (dragging) {
                    if (dx < -px(2)) facing = -1 else if (dx > px(2)) facing = 1
                    img.scaleX = if (facing < 0) -1f else 1f
                    val now = System.nanoTime() / 1_000_000
                    if (now - lastMove >= 16) {
                        lastMove = now
                        params.x = startX + dx
                        params.y = startY + dy
                        wm.updateViewLayout(root, params)
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    snap()
                } else if (System.currentTimeMillis() - downAt > 450) {
                    showMenu()
                } else {
                    react()
                }
                return true
            }
        }
        return false
    }

    private fun snap() {
        val sw = screenW()
        val sh = screenH()
        val left = params.x
        val right = sw - (params.x + boxW)
        val top = params.y
        val bottom = sh - (params.y + boxH)
        val min = minOf(left, right, top, bottom)
        if (min > px(28)) {
            applyMode(FULL)
            clampInto()
            return
        }
        when (min) {
            left -> dock(SIDE_LEFT, 0, clamp(params.y, 0, sh - boxH))
            right -> dock(SIDE_RIGHT, sw - boxW, clamp(params.y, 0, sh - boxH))
            top -> dock(TOP, clamp(params.x, 0, sw - boxW), 0)
            else -> dock(HEAD, clamp(params.x, 0, sw - boxW), sh - boxH)
        }
    }

    private fun dock(m: String, x: Int, y: Int) {
        applyMode(m)
        params.x = x
        params.y = y
        wm.updateViewLayout(root, params)
        scheduleChat()
    }

    private fun clampInto() {
        params.x = clamp(params.x, 0, screenW() - boxW)
        params.y = clamp(params.y, 0, screenH() - boxH)
        wm.updateViewLayout(root, params)
    }

    private fun react() {
        if (mode == FULL) jump()
        say(nextLine())
    }

    private fun jump() {
        val anim = ObjectAnimator.ofFloat(img, "translationY", 0f, -px(14).toFloat(), 0f)
        anim.duration = 420
        anim.start()
    }

    private fun showMenu() {
        hideMenu()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(px(6), px(4), px(6), px(4))
            background = GradientDrawable().apply {
                cornerRadius = px(14).toFloat()
                setColor(Color.WHITE)
                setStroke(px(1), Color.parseColor("#DCE4F2"))
            }
        }
        for (food in foods) {
            val cell = TextView(this).apply {
                text = food
                textSize = 20f
                setPadding(px(8), px(4), px(8), px(4))
                setOnClickListener {
                    hideMenu()
                    if (mode == FULL) jump()
                    say("好次！")
                }
            }
            row.addView(cell)
        }
        row.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val w = row.measuredWidth
        val h = row.measuredHeight
        val lp = WindowManager.LayoutParams(
            w,
            h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = clamp(params.x + boxW / 2 - w / 2, px(4), maxOf(px(4), screenW() - w - px(4)))
            y = (params.y - h - px(6)).coerceAtLeast(px(4))
        }
        menuView = row
        wm.addView(row, lp)
        handler.postDelayed({ hideMenu() }, 6000)
    }

    private fun hideMenu() {
        menuView?.let { runCatching { wm.removeView(it) } }
        menuView = null
    }

    private fun say(text: String) {
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        if (text.isEmpty()) return

        val tv = TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.parseColor("#22304d"))
            setPadding(px(10), px(6), px(10), px(6))
            background = GradientDrawable().apply {
                cornerRadius = px(12).toFloat()
                setColor(Color.WHITE)
                setStroke(px(1), Color.parseColor("#E3E9F5"))
            }
        }
        tv.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val bw = tv.measuredWidth
        val bh = tv.measuredHeight

        var x = params.x + boxW / 2 - bw / 2
        var y = params.y - bh - px(4)
        when (mode) {
            TOP -> y = params.y + boxH + px(4)
            SIDE_LEFT -> {
                x = params.x + boxW + px(2)
                y = params.y + boxH / 2 - bh / 2
            }
            SIDE_RIGHT -> {
                x = params.x - bw - px(2)
                y = params.y + boxH / 2 - bh / 2
            }
        }
        x = clamp(x, px(4), maxOf(px(4), screenW() - bw - px(4)))
        y = clamp(y, px(4), maxOf(px(4), screenH() - bh - px(4)))

        val lp = WindowManager.LayoutParams(
            bw,
            bh,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }
        bubble = tv
        wm.addView(tv, lp)
        handler.postDelayed({
            runCatching { wm.removeView(tv) }
            if (bubble === tv) bubble = null
        }, 2800)
    }

    private fun nextLine(): String {
        var index = Random.nextInt(lines.size)
        if (index == lastLine && lines.size > 2) index = (index + 1) % lines.size
        lastLine = index
        return lines[index]
    }

    private val chatTick = object : Runnable {
        override fun run() {
            if (!dragging && menuView == null && bubble == null) say(nextLine())
            scheduleChat()
        }
    }

    private fun scheduleChat() {
        handler.removeCallbacks(chatTick)
        handler.postDelayed(chatTick, 8000L + Random.nextLong(12000L))
    }

    private fun startBob() {
        bobber = ObjectAnimator.ofFloat(img, "translationY", 0f, -px(4).toFloat()).apply {
            duration = 1800
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }
    }

    private fun buildNotification(): Notification {
        val id = "whale-pet"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(id, "鲸鱼娘桌宠", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, id)
            .setContentTitle("鲸鱼娘桌宠运行中")
            .setContentText("拖动移动，拖到边上会躲起来")
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        bobber?.cancel()
        bubble?.let { runCatching { wm.removeView(it) } }
        menuView?.let { runCatching { wm.removeView(it) } }
        if (::root.isInitialized) runCatching { wm.removeView(root) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels
    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun clamp(v: Int, lo: Int, hi: Int) = if (hi <= lo) lo else v.coerceIn(lo, hi)

    companion object {
        const val FULL = "full"
        const val HEAD = "head"
        const val TOP = "top"
        const val SIDE_LEFT = "left"
        const val SIDE_RIGHT = "right"
    }
}
