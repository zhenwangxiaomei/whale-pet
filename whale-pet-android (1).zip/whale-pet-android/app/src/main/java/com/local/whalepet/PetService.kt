package com.local.whalepet

import android.animation.ObjectAnimator
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.random.Random

class PetService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var root: FrameLayout
    private lateinit var img: ImageView
    private lateinit var params: WindowManager.LayoutParams
    private var bubble: TextView? = null
    private var bobber: ObjectAnimator? = null

    private var mode = FULL
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var dragging = false
    private var longPressed = false
    private var downAt = 0L

    private val art = HashMap<String, Bitmap>()
    private val lines = arrayOf(
        "鲸鱼娘在这儿～",
        "今天也要好好干活哦",
        "要不要摸摸头？",
        "拖到屏幕边上，我会躲起来",
        "长按我，可以喂东西",
    )
    private val foods = arrayOf("🐟 小鱼干", "🍰 蛋糕", "💎 钻石")

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        for (name in listOf("whale.png", "head.png", "side.png", "body.png")) {
            art[name] = assets.open(name).use { BitmapFactory.decodeStream(it) }
        }

        root = FrameLayout(this)
        img = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        root.addView(img, FrameLayout.LayoutParams(-1, -1))

        params = WindowManager.LayoutParams(
            w(FULL), h(FULL),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenW() - w(FULL) - dp(16)
            y = screenH() / 2
        }

        applyMode(FULL)
        root.setOnTouchListener { _, e -> onTouch(e) }
        wm.addView(root, params)
        startBob()
    }

    private fun onTouch(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY
                startX = params.x; startY = params.y
                dragging = false; longPressed = false
                downAt = System.currentTimeMillis()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - downX).toInt()
                val dy = (e.rawY - downY).toInt()
                if (abs(dx) + abs(dy) > dp(6)) {
                    dragging = true
                    if (mode != FULL) applyMode(FULL)
                }
                if (dragging) {
                    params.x = startX + dx
                    params.y = startY + dy
                    wm.updateViewLayout(root, params)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) snap() else {
                    if (System.currentTimeMillis() - downAt > 450) showFoods() else react()
                }
                return true
            }
        }
        return false
    }

    private fun snap() {
        val sw = screenW(); val sh = screenH()
        val left = params.x
        val right = sw - (params.x + params.width)
        val top = params.y
        val bottom = sh - (params.y + params.height)
        val min = minOf(left, right, top, bottom)
        when {
            min > dp(28) -> { applyMode(FULL); clampInto() }
            min == left -> { params.y = clamp(params.y, 0, sh - h(SIDE)); applyModeAt(SIDE_LEFT, 0, params.y) }
            min == right -> { params.y = clamp(params.y, 0, sh - h(SIDE)); applyModeAt(SIDE_RIGHT, sw - w(SIDE), params.y) }
            min == top -> { params.x = clamp(params.x, 0, sw - w(TOP)); applyModeAt(TOP, params.x, 0) }
            else -> { params.x = clamp(params.x, 0, sw - w(HEAD)); applyModeAt(HEAD, params.x, sh - h(HEAD)) }
        }
    }

    private fun applyModeAt(m: String, x: Int, y: Int) {
        mode = m
        params.width = w(m); params.height = h(m)
        params.x = x; params.y = y
        wm.updateViewLayout(root, params)
        applyMode(m)
    }

    private fun applyMode(m: String) {
        mode = m
        val (name, flip) = when (m) {
            HEAD -> Pair("head.png", false)
            TOP -> Pair("body.png", false)
            SIDE_LEFT -> Pair("side.png", false)
            SIDE_RIGHT -> Pair("side.png", true)
            else -> Pair("whale.png", false)
        }
        img.setImageBitmap(art[name])
        img.scaleX = if (flip) -1f else 1f
    }

    private fun clampInto() {
        val sw = screenW(); val sh = screenH()
        params.x = clamp(params.x, 0, sw - params.width)
        params.y = clamp(params.y, 0, sh - params.height)
        wm.updateViewLayout(root, params)
    }

    private fun react() {
        jump()
        say(lines[Random.nextInt(lines.size)])
    }

    private fun jump() {
        val a = ObjectAnimator.ofFloat(img, "translationY", 0f, -dp(16).toFloat(), 0f)
        a.duration = 420
        a.start()
    }

    private fun showFoods() {
        val view = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val dialog = AlertDialog.Builder(this).setView(view).create()
        for (food in foods) {
            val b = TextView(this).apply {
                text = food
                textSize = 22f
                setPadding(dp(10), dp(6), dp(10), dp(6))
                setOnClickListener {
                    dialog.dismiss()
                    jump()
                    say("好次！")
                }
            }
            view.addView(b)
        }
        dialog.show()
    }

    private fun say(text: String) {
        bubble?.let { runCatching { wm.removeView(it) } }
        val tv = TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.parseColor("#22304d"))
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.WHITE)
                setStroke(dp(1), Color.parseColor("#E3E9F5"))
            }
        }
        tv.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val bw = tv.measuredWidth
        val bh = tv.measuredHeight
        val lp = WindowManager.LayoutParams(
            bw, bh,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = clamp(params.x + params.width / 2 - bw / 2, 0, screenW() - bw)
            y = (params.y - bh - dp(6)).coerceAtLeast(0)
        }
        bubble = tv
        wm.addView(tv, lp)
        tv.postDelayed({ runCatching { wm.removeView(tv) }; if (bubble === tv) bubble = null }, 2600)
    }

    private fun startBob() {
        bobber = ObjectAnimator.ofFloat(img, "translationY", 0f, -dp(5).toFloat()).apply {
            duration = 1800
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }
    }

    private fun buildNotification(): Notification {
        val id = "whale-pet"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(id, "鲸鱼娘桌宠", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, id)
            .setContentTitle("鲸鱼娘桌宠运行中")
            .setContentText("拖动移动，拖到边上会躲起来")
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        bobber?.cancel()
        if (::root.isInitialized) runCatching { wm.removeView(root) }
        bubble?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun clamp(v: Int, lo: Int, hi: Int) = if (hi <= lo) lo else v.coerceIn(lo, hi)

    private fun w(m: String) = when (m) {
        HEAD -> dp(130)
        TOP -> dp(101)
        SIDE_LEFT, SIDE_RIGHT -> dp(78)
        else -> dp(130)
    }

    private fun h(m: String) = when (m) {
        HEAD -> dp(92)
        TOP -> dp(124)
        SIDE_LEFT, SIDE_RIGHT -> dp(142)
        else -> dp(139)
    }

    companion object {
        const val FULL = "full"
        const val HEAD = "head"
        const val TOP = "top"
        const val SIDE_LEFT = "left"
        const val SIDE_RIGHT = "right"
    }
}
